package com.qqhd.demo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.gzgamut.demo.global.Global;
import com.gzgamut.demo.helper.NoConnectException;
import com.gzgamut.demo.model.Movement;
import com.gzgamut.demo.model.SDKCallBack;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private EditText et_mac;
    private Button bt_connect,bt_open_transparent,bt_close_transparent,
            bt_sos,bt_set_temperature_type,bt_get_temperature_type,bt_get_temperature,bt_start_heart_test,
    bt_close_heart_test,bt_get_heart_data;
    private Movement movement;
    private final String TAG=MainActivity.class.getName();
    private String mac;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView() {
        et_mac=findViewById(R.id.et_mac);
        bt_connect=findViewById(R.id.bt_connect);
        bt_open_transparent=findViewById(R.id.bt_open_transparent);
        bt_close_transparent=findViewById(R.id.bt_close_transparent);
        bt_sos=findViewById(R.id.bt_sos);
        bt_set_temperature_type=findViewById(R.id.bt_set_temperature_type);
        bt_get_temperature_type=findViewById(R.id.bt_get_temperature_type);
        bt_get_temperature=findViewById(R.id.bt_get_temperature);
        bt_start_heart_test=findViewById(R.id.bt_start_heart_test);
        bt_close_heart_test=findViewById(R.id.bt_close_heart_test);
        bt_get_heart_data=findViewById(R.id.bt_get_heart_data);
        movement=new Movement(getApplicationContext(), callBack);   //一定传ApplicationContext

        bt_connect.setOnClickListener(onClickListener);
        bt_open_transparent.setOnClickListener(onClickListener);
        bt_close_transparent.setOnClickListener(onClickListener);
        bt_sos.setOnClickListener(onClickListener);
        bt_set_temperature_type.setOnClickListener(onClickListener);
        bt_get_temperature_type.setOnClickListener(onClickListener);
        bt_get_temperature.setOnClickListener(onClickListener);
        bt_start_heart_test.setOnClickListener(onClickListener);
        bt_close_heart_test.setOnClickListener(onClickListener);
        bt_get_heart_data.setOnClickListener(onClickListener);
    }

    //开启蓝牙
    private boolean openBle(){
        BluetoothManager bluetoothManager= (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter=bluetoothManager.getAdapter();
        if (!adapter.isEnabled()){
            Intent intent=new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent,0);
            return false;
        }
        return true;
    }

    //地理位置权限
    private boolean requestPermission(){
        if (Build.VERSION.SDK_INT>=23){
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
                return false;
            }
        }
        return true;
    }

    //位置服务开启
    private boolean checkGPS(){
        LocationManager locationManager= (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager!=null&&!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            Intent intent=new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivityForResult(intent,2);
            return false;
        }
        return true;
    }

    //F3:0B:E5:D0:51:33
    private View.OnClickListener onClickListener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.bt_connect:
                    mac=et_mac.getText().toString();
                    if (TextUtils.isEmpty(mac)){
                        return;
                    }
                    if (openBle()&&requestPermission()&&checkGPS()){
                        movement.scan(null);        //也可传入设备名批量搜索
                    }
                    break;
                case R.id.bt_open_transparent:
                    try {
                        movement.transparentData(0x01);
                    } catch (NoConnectException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.bt_close_transparent:
                    try {
                        movement.transparentData(0);
                    } catch (NoConnectException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.bt_sos:
                    try {
                        movement.setSos();
                    } catch (NoConnectException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.bt_set_temperature_type:
                    try {
                        movement.setTemperature(0);
                    } catch (NoConnectException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.bt_get_temperature_type:
                    try {
                        movement.getTemperatureMode();
                    } catch (NoConnectException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.bt_get_temperature:
                    try {
                        movement.getTemperatureDataValue();
                    } catch (NoConnectException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.bt_start_heart_test:
                    try {
                        movement.writeHeart(Global.TYPE_HEART_START);
                    } catch (NoConnectException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.bt_close_heart_test:
                    try {
                        movement.writeHeart(Global.TYPE_HEART_STOP);
                    } catch (NoConnectException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.bt_get_heart_data:
                    try {
                        movement.writeHeart(Global.TYPE_HEART_GET);
                    } catch (NoConnectException e) {
                        e.printStackTrace();
                    }
                    break;
            }
        }
    };

    private SDKCallBack callBack=new SDKCallBack() {
        @Override
        public void onDeviceFound(FoundDevice device, int rssi, byte[] scanRecord) {
            if (device.getMac().equalsIgnoreCase(mac)){
                movement.stopScan();
                movement.connect(device.getMac());
            }
        }

        @Override
        public void onConnectionStateChange(int state) {
            if (state==STATE_CONNECT_SUCCESS){
                movement.openDescriptor();	//连接成功后一定要调用这个否则无法接收到数据。
				Log.e(TAG, "连接success");
            }else if (state==STATE_DISCONNECT){
                Log.e(TAG,"断开连接");
            }else if (state==STATE_CONNECT_FAIL){
                Log.e(TAG,"连接失败");
            }
        }

        @Override
        public void onDescriptorWrite(int status) {
            if (status==STATUS_SUCCESS){
                Log.e(TAG, "连接成功");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this,"连接成功",Toast.LENGTH_LONG).show();
                    }
                });
            }
        }

        @Override
        public void onSDKDeviceResponse(JSONObject value, int type) {
            Log.e(TAG, "type:"+type+"   data:"+value.toString());
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this,"type:"+type+"   data:"+value.toString(),Toast.LENGTH_LONG).show();
                }
            });
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            movement.disconnectDevice(true);
        } catch (NoConnectException e) {
            e.printStackTrace();
        }
    }
}
